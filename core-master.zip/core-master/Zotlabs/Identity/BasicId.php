<?php

namespace Zotlabs\Identity;

class BasicId {

	private $name;
	private $profile_photo;
	private $profile_url;
	private $address;
	private $protocol;





}

