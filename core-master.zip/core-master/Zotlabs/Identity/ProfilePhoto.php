<?php
namespace Zotlabs\Identity;

class ProfilePhoto {

	private $photo_large_url;
	private $photo_medium_url;
	private $photo_small_url;
	private $photo_mimetype;
	private $photo_updated;




}

